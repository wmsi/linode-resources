# Global configuration info

IOT_STATUS_FILE = "/var/www/html/wmsinh.org/public_html/cover-page/status.txt"
SCHOOL_SUBDOMAINS = ["berlin","canaan","colebrook","gorham","groveton","haverhill","lancaster","milan","pittsburgh","stark","stewartstown","strafford","whitefield"]
