<h1>Flask App Back End<h1>
<hr>
<p>
	This is were our flask app source control lives (for now). Some files have been removed because they contain sensitive information. For a better understanding of the complete Linode structure check out our Google docs and Lucidcharts.
</p>